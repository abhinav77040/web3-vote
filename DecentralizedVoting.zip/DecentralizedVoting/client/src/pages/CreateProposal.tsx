import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useWeb3 } from "@/contexts/Web3Context";
import { createProposal } from "@/lib/web3";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { VOTING_DURATIONS, CONTRACT_ADDRESSES } from "@shared/constants";
import { CreateProposalFormData } from "@shared/types";

// Simple form validation schema
const createProposalSchema = z.object({
  title: z.string().min(3, "Title is too short").max(100, "Title is too long"),
  description: z.string().min(10, "Description is too short").max(500, "Description is too long"),
  duration: z.number().min(1, "Duration must be positive"),
});

interface CreateProposalProps {
  onProposalCreated: () => void;
}

const CreateProposal: React.FC<CreateProposalProps> = ({ onProposalCreated }) => {
  const { isConnected, account, chainId, setTransactionStatus } = useWeb3();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const { register, handleSubmit, reset, formState: { errors } } = useForm<CreateProposalFormData>({
    resolver: zodResolver(createProposalSchema),
    defaultValues: {
      title: "",
      description: "",
      duration: 5,
    },
  });

  // Function to create a quick proposal with 1-hour duration
  const createQuickProposal = async () => {
    // Check form validity first (at least title and description)
    const title = document.getElementById("proposal-title") as HTMLInputElement;
    const description = document.getElementById("proposal-description") as HTMLTextAreaElement;
    
    if (!title?.value || title.value.length < 3) {
      toast({
        title: "Invalid Title",
        description: "Please enter a valid title (at least 3 characters).",
        variant: "destructive",
      });
      return;
    }
    
    if (!description?.value || description.value.length < 10) {
      toast({
        title: "Invalid Description",
        description: "Please enter a valid description (at least 10 characters).",
        variant: "destructive",
      });
      return;
    }
    
    // Use the same submit handler but with hardcoded 1-hour duration
    onSubmit({
      title: title.value,
      description: description.value,
      duration: 1 // 1 hour duration
    });
  };

  const onSubmit = async (data: CreateProposalFormData) => {
    // Check for wallet connection
    if (!isConnected || !account || !chainId) {
      toast({
        title: "Wallet Not Connected",
        description: "Please connect your wallet to create a proposal.",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Show transaction in progress
      setTransactionStatus(
        "processing",
        "Creating Proposal",
        "Please confirm the transaction in your wallet..."
      );

      // Create the proposal on blockchain
      const result = await createProposal(
        chainId,
        data.title,
        data.description,
        data.duration
      );

      // Calculate end time based on hours instead of days
      const endTime = new Date();
      endTime.setHours(endTime.getHours() + data.duration);

      // Store in our database 
      // Make sure the date is sent properly
      try {
        console.log("Saving proposal to database");
        const apiResult = await apiRequest("POST", "/api/proposals", {
          title: data.title,
          description: data.description,
          creatorAddress: account,
          network: chainId,
          chainId: parseInt(chainId),
          contractAddress: CONTRACT_ADDRESSES[chainId],
          proposalId: result.proposalId || "1", // Fallback if we can't get the ID
          duration: data.duration,
          endTime: endTime.toISOString(), // Make sure it's properly formatted
          active: true,
        });
        console.log("Proposal saved to database", apiResult);
      } catch (error) {
        console.error("Error saving proposal to database:", error);
        // We'll still consider it a success since the blockchain transaction worked
        toast({
          title: "Warning",
          description: "Proposal created on blockchain but there was an issue saving to our database.",
          variant: "destructive",
        });
      }

      // Show success message
      setTransactionStatus(
        "success",
        "Proposal Created",
        "Your proposal has been successfully created and is now available for voting.",
        result.txHash
      );
      
      // Reset form
      reset();
      
      // Refresh data
      queryClient.invalidateQueries({ queryKey: [`/api/proposals/${chainId}`] });
      
      // Navigate to proposals tab after delay
      setTimeout(() => {
        onProposalCreated();
      }, 2000);
      
    } catch (error) {
      console.error("Error creating proposal:", error);
      
      // Show error message
      setTransactionStatus(
        "error",
        "Proposal Creation Failed",
        "Failed to create proposal. Please try again."
      );
      
      toast({
        title: "Error",
        description: "Could not create proposal. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-2">Create New Proposal</h2>
        <p className="text-gray-600">Submit a new proposal for the community to vote on. All proposals will be stored on-chain.</p>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="space-y-4">
            <div>
              <label htmlFor="proposal-title" className="block text-sm font-medium text-gray-700 mb-1">
                Proposal Title
              </label>
              <input
                type="text"
                id="proposal-title"
                className={`w-full px-3 py-2 border ${
                  errors.title ? "border-red-300" : "border-gray-300"
                } rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                placeholder="Enter a descriptive title"
                {...register("title")}
              />
              {errors.title && (
                <p className="mt-1 text-sm text-red-600">{errors.title.message}</p>
              )}
            </div>
            
            <div>
              <label htmlFor="proposal-description" className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                id="proposal-description"
                rows={4}
                className={`w-full px-3 py-2 border ${
                  errors.description ? "border-red-300" : "border-gray-300"
                } rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                placeholder="Provide details about your proposal"
                {...register("description")}
              ></textarea>
              {errors.description && (
                <p className="mt-1 text-sm text-red-600">{errors.description.message}</p>
              )}
            </div>
            
            <div>
              <label htmlFor="proposal-duration" className="block text-sm font-medium text-gray-700 mb-1">
                Voting Duration
              </label>
              <select
                id="proposal-duration"
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                {...register("duration", { valueAsNumber: true })}
              >
                {VOTING_DURATIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              {errors.duration && (
                <p className="mt-1 text-sm text-red-600">{errors.duration.message}</p>
              )}
            </div>
            
            <div className="pt-4 border-t border-gray-200">
              <div className="flex gap-4 mb-4">
                <button
                  type="submit"
                  className={`flex-1 bg-primary-500 hover:bg-primary-600 text-white py-2 px-4 rounded-md font-medium transition-colors ${
                    isSubmitting || !isConnected ? "opacity-70 cursor-not-allowed" : ""
                  }`}
                  disabled={isSubmitting || !isConnected}
                >
                  {isSubmitting ? (
                    <div className="flex items-center justify-center">
                      <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white mr-2"></div>
                      <span>Creating...</span>
                    </div>
                  ) : (
                    "Create Proposal"
                  )}
                </button>
                
                <button
                  type="button"
                  onClick={createQuickProposal}
                  className={`flex-1 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white py-2 px-4 rounded-md font-medium transition-colors ${
                    isSubmitting || !isConnected ? "opacity-70 cursor-not-allowed" : ""
                  }`}
                  disabled={isSubmitting || !isConnected}
                >
                  {isSubmitting ? (
                    <div className="flex items-center justify-center">
                      <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white mr-2"></div>
                      <span>Creating...</span>
                    </div>
                  ) : (
                    "Quick 1-Hour Proposal"
                  )}
                </button>
              </div>
              
              <div className="text-center text-xs text-gray-600 mb-2">
                The Quick Proposal button creates a proposal with a 1-hour voting duration
              </div>
            </div>
            
            <div className="text-xs text-gray-500">
              <p>Note: Creating a proposal requires a small gas fee to cover the transaction cost.</p>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateProposal;
