import React, { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useWeb3 } from "@/contexts/Web3Context";
import ProposalCard from "@/components/ProposalCard";
import { ProposalData } from "@shared/types";
import { FILTER_OPTIONS } from "@shared/constants";

interface ActiveProposalsProps {
  onCreateProposal: () => void;
}

const ActiveProposals: React.FC<ActiveProposalsProps> = ({ onCreateProposal }) => {
  const { chainId, isConnected } = useWeb3();
  const [filter, setFilter] = useState("all");
  const [filteredProposals, setFilteredProposals] = useState<ProposalData[]>([]);

  // Fetch proposals from API
  const { data: proposals, isLoading, error, refetch } = useQuery<ProposalData[]>({
    queryKey: chainId ? [`/api/proposals/${chainId}`] : ["no-chain"],
    enabled: !!chainId,
    staleTime: 10000, // Cache for only 10 seconds to get fresher data
    refetchInterval: 15000, // Auto-refresh every 15 seconds
  });
  
  // Force refresh data every 15 seconds to ensure votes are up to date
  useEffect(() => {
    const interval = setInterval(() => {
      if (chainId) {
        refetch();
      }
    }, 15000);
    
    return () => clearInterval(interval);
  }, [chainId, refetch]);

  // Update filtered proposals when proposals or filter changes
  useEffect(() => {
    if (!proposals) {
      setFilteredProposals([]);
      return;
    }
    
    let result = [...proposals];
    
    // Apply sorting based on filter
    switch (filter) {
      case "ending_soon":
        // Sort by end time - closest first
        result.sort((a, b) => new Date(a.endTime).getTime() - new Date(b.endTime).getTime());
        break;
      case "most_votes":
        // Sort by total vote count - highest first
        result.sort((a, b) => {
          const totalVotesA = (a.yesVotes || 0) + (a.noVotes || 0);
          const totalVotesB = (b.yesVotes || 0) + (b.noVotes || 0);
          return totalVotesB - totalVotesA;
        });
        break;
      case "recent":
        // Sort by creation date - newest first
        result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        break;
    }
    
    setFilteredProposals(result);
  }, [proposals, filter]);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-gray-900">Active Proposals</h2>
        <div className="flex space-x-2">
          <select
            className="text-sm bg-white border border-gray-300 rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          >
            {FILTER_OPTIONS.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>
      
      {/* Proposals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Loading State */}
        {isLoading && (
          <div className="col-span-1 md:col-span-2 lg:col-span-3">
            <div className="flex justify-center items-center p-8">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-500"></div>
            </div>
          </div>
        )}
        
        {/* Error State */}
        {error && (
          <div className="col-span-1 md:col-span-2 lg:col-span-3">
            <div className="bg-red-50 border-l-4 border-red-400 p-4">
              <div className="flex">
                <div className="flex-shrink-0">
                  <i className="ri-error-warning-line text-red-400"></i>
                </div>
                <div className="ml-3">
                  <p className="text-sm text-red-700">
                    Error loading proposals. Please try again.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {/* Empty State */}
        {!isLoading && !error && filteredProposals.length === 0 && (
          <div className="col-span-1 md:col-span-2 lg:col-span-3">
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <i className="ri-inbox-line text-gray-400 text-5xl mb-4"></i>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No active proposals</h3>
              <p className="text-gray-600 mb-4">There are currently no active proposals on this network.</p>
              <button 
                className="bg-primary-500 hover:bg-primary-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                onClick={onCreateProposal}
                disabled={!isConnected}
              >
                {isConnected ? 'Create a Proposal' : 'Connect Wallet to Create'}
              </button>
            </div>
          </div>
        )}
        
        {/* Proposal Cards */}
        {!isLoading && filteredProposals.map((proposal) => (
          <ProposalCard key={proposal.id} proposal={proposal} />
        ))}
      </div>
    </div>
  );
};

export default ActiveProposals;
