import React, { useState } from "react";
import StatusBar from "@/components/StatusBar";
import NetworkSelector from "@/components/NetworkSelector";
import ActiveProposals from "./ActiveProposals";
import CreateProposal from "./CreateProposal";
import VotingResults from "./VotingResults";

type TabType = "activeProposals" | "createProposal" | "votingResults";

const Home: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>("activeProposals");

  const handleTabChange = (tab: TabType) => {
    setActiveTab(tab);
  };

  return (
    <main className="flex-grow">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Mobile network selector */}
        <div className="block md:hidden mb-6">
          <label htmlFor="mobile-network" className="block text-sm font-medium text-gray-700 mb-1">
            Select Network
          </label>
          <NetworkSelector />
        </div>
        
        {/* Page introduction */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">
            <span className="bg-gradient-to-r from-blue-600 to-violet-600 text-transparent bg-clip-text">Web3Vote</span> - Decentralized Voting Platform
          </h1>
          <p className="text-gray-600 max-w-3xl">
            Create and participate in transparent voting proposals using blockchain technology. 
            Connect your wallet to view active proposals and cast your vote securely on the blockchain.
          </p>
        </div>
        
        {/* Status bar */}
        <StatusBar />
        
        {/* Tab navigation */}
        <div className="border-b border-gray-200 mb-6">
          <nav className="-mb-px flex space-x-8">
            <button
              className={`whitespace-nowrap pb-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "activeProposals"
                  ? "border-primary-500 text-primary-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
              onClick={() => handleTabChange("activeProposals")}
            >
              Active Proposals
            </button>
            <button
              className={`whitespace-nowrap pb-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "createProposal"
                  ? "border-primary-500 text-primary-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
              onClick={() => handleTabChange("createProposal")}
            >
              Create Proposal
            </button>
            <button
              className={`whitespace-nowrap pb-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "votingResults"
                  ? "border-primary-500 text-primary-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
              onClick={() => handleTabChange("votingResults")}
            >
              Results
            </button>
          </nav>
        </div>
        
        {/* Tab content */}
        {activeTab === "activeProposals" && <ActiveProposals onCreateProposal={() => handleTabChange("createProposal")} />}
        {activeTab === "createProposal" && <CreateProposal onProposalCreated={() => handleTabChange("activeProposals")} />}
        {activeTab === "votingResults" && <VotingResults />}
      </div>
    </main>
  );
};

export default Home;
