import React from "react";
import { useQuery } from "@tanstack/react-query";
import { useWeb3 } from "@/contexts/Web3Context";
import { ProposalData } from "@shared/types";
import { truncateAddress } from "@/lib/web3";

const VotingResults: React.FC = () => {
  const { chainId, getNetworkById } = useWeb3();
  
  // Fetch completed proposals
  const { data: proposals, isLoading, error } = useQuery<ProposalData[]>({
    queryKey: chainId ? [`/api/proposals/${chainId}/completed`] : ["no-chain"],
    enabled: !!chainId,
  });

  // Format date for display
  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center p-8">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border-l-4 border-red-400 p-4">
        <div className="flex">
          <div className="flex-shrink-0">
            <i className="ri-error-warning-line text-red-400"></i>
          </div>
          <div className="ml-3">
            <p className="text-sm text-red-700">
              Error loading completed proposals. Please try again.
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (!proposals || proposals.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-md p-8 text-center">
        <i className="ri-inbox-line text-gray-400 text-5xl mb-4"></i>
        <h3 className="text-lg font-medium text-gray-900 mb-2">No completed proposals</h3>
        <p className="text-gray-600">There are no completed proposals to display yet.</p>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-2">Voting Results</h2>
        <p className="text-gray-600">View the results of completed proposals across all networks.</p>
      </div>
      
      <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
        <table className="min-w-full divide-y divide-gray-300">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6">Proposal</th>
              <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Network</th>
              <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Result</th>
              <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Votes</th>
              <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">End Date</th>
              <th scope="col" className="relative py-3.5 pl-3 pr-4 sm:pr-6">
                <span className="sr-only">View</span>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200 bg-white">
            {proposals.map((proposal) => {
              const yesVotes = proposal.yesVotes || 0;
              const noVotes = proposal.noVotes || 0;
              const totalVotes = yesVotes + noVotes;
              const yesPercentage = totalVotes > 0 ? Math.round((yesVotes / totalVotes) * 100) : 0;
              const noPercentage = totalVotes > 0 ? Math.round((noVotes / totalVotes) * 100) : 0;
              const passed = yesVotes > noVotes;
              const network = getNetworkById(proposal.network);
              
              return (
                <tr key={proposal.id}>
                  <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6">
                    {proposal.title}
                  </td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                    {network && (
                      <span className={`network-badge ${network.badge}`}>
                        {network.name.split(" ")[0]}
                      </span>
                    )}
                  </td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm">
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        passed
                          ? "bg-green-100 text-green-800"
                          : "bg-red-100 text-red-800"
                      }`}
                    >
                      {passed ? "Passed" : "Rejected"}
                    </span>
                  </td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                    <div>Yes: {yesVotes} ({yesPercentage}%)</div>
                    <div>No: {noVotes} ({noPercentage}%)</div>
                  </td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                    {formatDate(proposal.endTime)}
                  </td>
                  <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-6">
                    <a href="#" className="text-primary-600 hover:text-primary-900">
                      View
                    </a>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default VotingResults;
