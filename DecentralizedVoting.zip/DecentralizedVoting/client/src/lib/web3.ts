// Define a global type for window.ethereum
declare global {
  interface Window {
    ethereum: any;
  }
}

import { ethers } from "ethers";
import VotingContract from "../contracts/VotingContract.json";
import { CONTRACT_ADDRESSES } from "@shared/constants";

/**
 * Simple Web3 utility functions for interacting with Ethereum contracts.
 * Focused on core functionality with minimal complexity.
 */

// Basic provider for browser environments
export const getProvider = () => {
  if (!window.ethereum) {
    throw new Error("MetaMask not installed. Please install MetaMask to use this app.");
  }
  return new ethers.BrowserProvider(window.ethereum);
};

// Get signer for transactions
export const getSigner = async () => {
  const provider = getProvider();
  return await provider.getSigner();
};

// Get contract instance with or without signer
export const getContract = async (chainId: string, needSigner = false) => {
  const address = CONTRACT_ADDRESSES[chainId];
  
  if (!address || address === "0x0000000000000000000000000000000000000000") {
    throw new Error(`No contract deployed on network ${chainId}`);
  }
  
  if (needSigner) {
    const signer = await getSigner();
    return new ethers.Contract(address, VotingContract.abi, signer);
  } else {
    const provider = getProvider();
    return new ethers.Contract(address, VotingContract.abi, provider);
  }
};

// Create a new proposal
export const createProposal = async (chainId: string, title: string, description: string, durationDays: number) => {
  try {
    const contract = await getContract(chainId, true);
    const durationSeconds = durationDays * 24 * 60 * 60;
    
    console.log(`Creating proposal: "${title}" with duration ${durationDays} days`);
    
    // Create the proposal
    const tx = await contract.createProposal(title, description, durationSeconds);
    console.log("Transaction sent:", tx.hash);
    
    // Wait for confirmation
    const receipt = await tx.wait();
    console.log("Transaction confirmed:", receipt);
    
    // Find ProposalCreated event 
    // Note: In case of errors here, we'll return the transaction hash anyway
    let proposalId = "0";
    try {
      // Extract proposalId from the blockchain receipt
      for (const log of receipt.logs) {
        // For simplicity - just use the transaction data
        if (log && log.topics && log.topics[0]) {
          const eventHash = log.topics[0];
          // Event signature for ProposalCreated
          const proposalCreatedHash = ethers.id("ProposalCreated(uint256,address,string,uint256)");
          
          if (eventHash === proposalCreatedHash && log.topics[1]) {
            proposalId = parseInt(log.topics[1], 16).toString();
            break;
          }
        }
      }
    } catch (err) {
      console.error("Error parsing log:", err);
    }
    
    return {
      txHash: receipt.hash,
      proposalId: proposalId || "0" // Fallback to 0 if we couldn't extract
    };
  } catch (error) {
    console.error("Error creating proposal:", error);
    throw error;
  }
};

// Vote on a proposal
export const voteOnProposal = async (chainId: string, proposalId: string, vote: boolean) => {
  try {
    const contract = await getContract(chainId, true);
    
    // Submit vote
    const tx = await contract.vote(proposalId, vote);
    const receipt = await tx.wait();
    
    return {
      txHash: receipt.hash
    };
  } catch (error) {
    console.error("Error voting on proposal:", error);
    throw error;
  }
};

// Get a single proposal
export const getProposal = async (chainId: string, proposalId: string) => {
  try {
    const contract = await getContract(chainId);
    const result = await contract.getProposal(proposalId);
    
    return {
      title: result.title,
      description: result.description,
      creator: result.creator,
      endTime: new Date(Number(result.endTime) * 1000),
      yesVotes: Number(result.yesVotes),
      noVotes: Number(result.noVotes),
      executed: result.executed,
      active: Number(result.endTime) * 1000 > Date.now() && !result.executed
    };
  } catch (error) {
    console.error(`Error getting proposal ${proposalId}:`, error);
    throw error;
  }
};

// Get all proposals
export const getProposals = async (chainId: string) => {
  try {
    const contract = await getContract(chainId);
    const count = await contract.getProposalCount();
    const countNum = Number(count);
    
    console.log(`Found ${countNum} proposals on chain ${chainId}`);
    
    const proposals = [];
    for (let i = 1; i <= countNum; i++) {
      try {
        const proposal = await getProposal(chainId, i.toString());
        proposals.push({ 
          ...proposal, 
          id: i.toString(),
          proposalId: i.toString()
        });
      } catch (error) {
        console.error(`Error fetching proposal ${i}:`, error);
      }
    }
    
    return proposals;
  } catch (error) {
    console.error("Error fetching proposals:", error);
    return [];
  }
};

// Utility to format addresses
export const truncateAddress = (address: string) => {
  if (!address) return "";
  return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
};

// Chain ID to hex for MetaMask
export const chainIdToHex = (chainId: string) => {
  return `0x${parseInt(chainId).toString(16)}`;
};
