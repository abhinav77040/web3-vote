import React from "react";
import { useWeb3 } from "@/contexts/Web3Context";
import { truncateAddress } from "@/lib/web3";

const WalletConnect: React.FC = () => {
  const { isConnected, isConnecting, account, connectWallet, disconnectWallet } = useWeb3();

  if (isConnected && account) {
    return (
      <div className="flex items-center space-x-2">
        <div className="px-4 py-2 bg-gray-100 rounded-lg flex items-center">
          <div className="h-2 w-2 rounded-full bg-green-500 mr-2"></div>
          <span className="text-sm font-medium">{truncateAddress(account)}</span>
        </div>
        <button 
          className="text-gray-500 hover:text-gray-700" 
          onClick={disconnectWallet}
          aria-label="Disconnect wallet"
        >
          <i className="ri-logout-box-line"></i>
        </button>
      </div>
    );
  }

  return (
    <button
      className={`bg-primary-500 hover:bg-primary-600 text-white px-4 py-2 rounded-lg flex items-center transition-colors ${isConnecting ? 'opacity-70 cursor-not-allowed' : ''}`}
      onClick={connectWallet}
      disabled={isConnecting}
    >
      {isConnecting ? (
        <>
          <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white mr-2"></div>
          <span>Connecting...</span>
        </>
      ) : (
        <>
          <i className="ri-wallet-3-line mr-2"></i>
          <span>Connect Wallet</span>
        </>
      )}
    </button>
  );
};

export default WalletConnect;
