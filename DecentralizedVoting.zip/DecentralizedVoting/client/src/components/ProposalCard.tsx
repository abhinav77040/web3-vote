import React, { useState } from "react";
import { useWeb3 } from "@/contexts/Web3Context";
import { truncateAddress, voteOnProposal } from "@/lib/web3";
import { useToast } from "@/hooks/use-toast";
import { ProposalData } from "@shared/types";
import { useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface ProposalCardProps {
  proposal: ProposalData;
}

const ProposalCard: React.FC<ProposalCardProps> = ({ proposal }) => {
  const { isConnected, account, chainId, setTransactionStatus, getCurrentNetwork } = useWeb3();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const network = getCurrentNetwork();
  const [isVoting, setIsVoting] = useState(false);
  
  // Improved time remaining calculation with hours and minutes
  const getTimeRemaining = () => {
    const now = new Date();
    const end = new Date(proposal.endTime);
    const diffMs = end.getTime() - now.getTime();
    
    if (diffMs <= 0) return "Ended";
    
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    if (diffDays > 0) return `${diffDays} day${diffDays > 1 ? 's' : ''}`;
    
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    if (diffHours > 0) return `${diffHours} hour${diffHours > 1 ? 's' : ''}`;
    
    const diffMinutes = Math.floor(diffMs / (1000 * 60));
    return `${diffMinutes} minute${diffMinutes > 1 ? 's' : ''}`;
  };

  // Calculate yes vote percentage
  const getYesPercentage = () => {
    const yes = proposal.yesVotes || 0;
    const no = proposal.noVotes || 0;
    const total = yes + no;
    
    if (total === 0) return 50; // Default to 50% if no votes
    return Math.round((yes / total) * 100);
  };

  // Handle voting
  const handleVote = async (vote: boolean) => {
    // Check wallet connection
    if (!isConnected || !account || !chainId) {
      toast({
        title: "Wallet Not Connected",
        description: "Please connect your wallet to vote on proposals.",
        variant: "destructive",
      });
      return;
    }
    
    // Prevent double voting
    if (isVoting) return;
    
    setIsVoting(true);

    try {
      // Show transaction status
      setTransactionStatus(
        "processing",
        "Voting in Progress",
        "Please confirm the transaction in your wallet..."
      );

      // Send blockchain transaction
      const result = await voteOnProposal(chainId, proposal.proposalId, vote);
      
      // Save vote in database
      await apiRequest("POST", "/api/votes", {
        proposalId: proposal.id,
        voterAddress: account,
        vote: vote,
        txHash: result.txHash
      });

      // Update proposal votes locally to show immediate feedback
      // This will be overwritten when the query is refreshed
      const updatedProposal = { 
        ...proposal,
        yesVotes: (proposal.yesVotes || 0) + (vote ? 1 : 0),
        noVotes: (proposal.noVotes || 0) + (vote ? 0 : 1)
      };

      // Success notification
      setTransactionStatus(
        "success",
        "Vote Recorded Successfully",
        `You voted ${vote ? "YES" : "NO"} on proposal: ${proposal.title}`,
        result.txHash
      );

      // Toast notification with vote details
      toast({
        title: "Vote Counted",
        description: `Your ${vote ? "YES" : "NO"} vote has been recorded and counted.`,
      });

      // Refresh all proposals data
      queryClient.invalidateQueries({ queryKey: [`/api/proposals/${chainId}`] });
      
      // Refresh this specific proposal to get updated vote counts
      queryClient.invalidateQueries({ queryKey: [`/api/proposals/${chainId}/${proposal.id}`] });

    } catch (error) {
      console.error("Error voting:", error);
      setTransactionStatus(
        "error",
        "Vote Failed",
        "Your vote could not be recorded. Please try again."
      );
    } finally {
      setIsVoting(false);
    }
  };

  // Network badge styling
  const networkBadge = network ? network.badge : "bg-gray-100 text-gray-800";
  const yesPercentage = getYesPercentage();

  return (
    <div className="proposal-card bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
      <div className="px-6 py-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-semibold text-gray-900 line-clamp-1">{proposal.title}</h3>
          <span className={`network-badge ${networkBadge}`}>{network?.name.split(' ')[0]}</span>
        </div>
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">{proposal.description}</p>
        <div className="flex justify-between text-xs text-gray-500 mb-3">
          <span>Proposed by: {truncateAddress(proposal.creatorAddress)}</span>
          <span>Ends in: {getTimeRemaining()}</span>
        </div>
        
        {/* Voting Progress */}
        <div className="mb-4">
          <div className="flex justify-between text-sm mb-1 font-medium">
            <span className="text-green-600">Yes: {proposal.yesVotes || 0} votes</span>
            <span className="text-red-600">No: {proposal.noVotes || 0} votes</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div 
              className="bg-primary-500 h-3 rounded-full transition-all duration-500" 
              style={{ width: `${yesPercentage}%` }}
            ></div>
          </div>
          <div className="mt-1 text-xs text-center text-gray-500">
            {yesPercentage}% Yes / {100 - yesPercentage}% No
          </div>
        </div>
        
        {/* Voting Controls */}
        <div className="flex space-x-2 justify-center">
          <button 
            className="flex-1 bg-green-500 hover:bg-green-600 text-white py-2 rounded-md text-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            onClick={() => handleVote(true)}
            disabled={!isConnected || !proposal.active || isVoting}
          >
            {isVoting ? (
              <div className="flex items-center justify-center">
                <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white mr-1"></div>
                <span>Voting...</span>
              </div>
            ) : "Vote Yes"}
          </button>
          <button 
            className="flex-1 bg-red-500 hover:bg-red-600 text-white py-2 rounded-md text-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            onClick={() => handleVote(false)}
            disabled={!isConnected || !proposal.active || isVoting}
          >
            {isVoting ? (
              <div className="flex items-center justify-center">
                <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white mr-1"></div>
                <span>Voting...</span>
              </div>
            ) : "Vote No"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProposalCard;
