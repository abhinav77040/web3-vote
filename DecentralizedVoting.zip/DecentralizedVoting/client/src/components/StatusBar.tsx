import React from "react";
import { useWeb3 } from "@/contexts/Web3Context";

const StatusBar: React.FC = () => {
  const { isConnected } = useWeb3();

  if (isConnected) {
    return (
      <div className="bg-green-50 border-l-4 border-green-400 p-4 mb-8">
        <div className="flex">
          <div className="flex-shrink-0">
            <i className="ri-checkbox-circle-line text-green-400"></i>
          </div>
          <div className="ml-3">
            <p className="text-sm text-green-700">
              Wallet connected! You can now vote on proposals.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-amber-50 border-l-4 border-amber-400 p-4 mb-8">
      <div className="flex">
        <div className="flex-shrink-0">
          <i className="ri-error-warning-line text-amber-400"></i>
        </div>
        <div className="ml-3">
          <p className="text-sm text-amber-700">
            Please connect your wallet to participate in voting. Make sure you're connected to the correct network.
          </p>
        </div>
      </div>
    </div>
  );
};

export default StatusBar;
