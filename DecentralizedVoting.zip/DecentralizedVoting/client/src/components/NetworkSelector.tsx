import React from "react";
import { useWeb3 } from "@/contexts/Web3Context";
import { NETWORKS } from "@shared/constants";

const NetworkSelector: React.FC = () => {
  const { chainId, switchNetwork, isConnected } = useWeb3();
  
  const handleNetworkChange = async (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newChainId = e.target.value;
    if (chainId !== newChainId) {
      await switchNetwork(newChainId);
    }
  };

  return (
    <div className="relative">
      <select
        id="network-selector"
        className="pl-8 pr-10 py-2 text-sm bg-gray-100 border border-gray-300 rounded-lg appearance-none focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
        value={chainId || "11155111"}
        onChange={handleNetworkChange}
        disabled={!isConnected}
      >
        {NETWORKS.map((network) => (
          <option key={network.id} value={network.id}>
            {network.name}
          </option>
        ))}
      </select>
      <div className="absolute inset-y-0 left-0 flex items-center pl-2 pointer-events-none">
        <div className={`h-3 w-3 rounded-full ${isConnected ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`}></div>
      </div>
      <div className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
        <i className="ri-arrow-down-s-line text-gray-400"></i>
      </div>
    </div>
  );
};

export default NetworkSelector;
