import React from "react";
import NetworkSelector from "./NetworkSelector";
import WalletConnect from "./WalletConnect";
import { Link } from "wouter";

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Link href="/">
              <a className="flex items-center">
                <div className="flex-shrink-0">
                  <i className="ri-checkbox-multiple-line text-primary-500 text-3xl"></i>
                </div>
                <h1 className="ml-2 text-xl font-bold text-gray-900 bg-gradient-to-r from-blue-600 to-violet-600 text-transparent bg-clip-text">Web3Vote</h1>
              </a>
            </Link>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="hidden md:block">
              <NetworkSelector />
            </div>
            <WalletConnect />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
