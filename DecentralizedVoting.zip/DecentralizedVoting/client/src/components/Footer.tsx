import React from "react";

const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-gray-200">
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="md:flex md:items-center md:justify-between">
          <div className="flex justify-center md:order-2 space-x-6">
            <a href="https://github.com" className="text-gray-400 hover:text-gray-500" target="_blank" rel="noopener noreferrer">
              <i className="ri-github-fill text-lg"></i>
              <span className="sr-only">GitHub</span>
            </a>
            <a href="https://discord.com" className="text-gray-400 hover:text-gray-500" target="_blank" rel="noopener noreferrer">
              <i className="ri-discord-fill text-lg"></i>
              <span className="sr-only">Discord</span>
            </a>
            <a href="https://twitter.com" className="text-gray-400 hover:text-gray-500" target="_blank" rel="noopener noreferrer">
              <i className="ri-twitter-fill text-lg"></i>
              <span className="sr-only">Twitter</span>
            </a>
          </div>
          <div className="mt-8 md:mt-0 md:order-1">
            <p className="text-center text-sm text-gray-500">
              &copy; {new Date().getFullYear()} <span className="font-medium">Web3Vote</span>. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
