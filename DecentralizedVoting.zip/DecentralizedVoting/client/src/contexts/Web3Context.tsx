import React, { createContext, useState, useEffect, useContext, ReactNode } from "react";
import { ethers } from "ethers";
import { NETWORKS, DEFAULT_NETWORK } from "@shared/constants";
import { Network, TransactionState, Web3ContextType, TransactionStatus } from "@shared/types";
import { useToast } from "@/hooks/use-toast";

const initialTransactionState: TransactionState = {
  status: "idle",
  title: "",
  message: "",
  txHash: undefined,
  isOpen: false,
};

const Web3Context = createContext<Web3ContextType | undefined>(undefined);

export function Web3Provider({ children }: { children: ReactNode }) {
  const [account, setAccount] = useState<string | null>(null);
  const [chainId, setChainId] = useState<string | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [transaction, setTransaction] = useState<TransactionState>(initialTransactionState);
  const { toast } = useToast();

  // Check if window.ethereum is available
  const isMetaMaskAvailable = typeof window !== "undefined" && window.ethereum !== undefined;

  // Function to get provider/signer
  const getProvider = () => {
    if (!isMetaMaskAvailable) return null;
    return new ethers.BrowserProvider(window.ethereum);
  };

  const getSigner = async () => {
    const provider = getProvider();
    if (!provider) return null;
    return await provider.getSigner();
  };

  // Connect wallet
  const connectWallet = async () => {
    if (!isMetaMaskAvailable) {
      toast({
        title: "MetaMask not found",
        description: "Please install MetaMask extension to use this application",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsConnecting(true);
      setTransactionStatus("processing", "Connecting Wallet", "Please confirm the connection in your wallet...");

      const provider = getProvider();
      if (!provider) throw new Error("Provider not available");

      const accounts = await provider.send("eth_requestAccounts", []);
      const network = await provider.getNetwork();
      
      setAccount(accounts[0]);
      setChainId(network.chainId.toString());
      setIsConnected(true);
      
      setTransactionStatus("success", "Wallet Connected", "Your wallet has been successfully connected.");
      
      // Close transaction modal after a delay
      setTimeout(() => {
        closeTransactionModal();
      }, 2000);
      
      // Restore session later if needed
      localStorage.setItem("walletConnected", "true");
    } catch (error) {
      console.error("Error connecting wallet:", error);
      setTransactionStatus("error", "Connection Failed", "Failed to connect wallet. Please try again.");
    } finally {
      setIsConnecting(false);
    }
  };

  // Disconnect wallet
  const disconnectWallet = () => {
    setAccount(null);
    setChainId(null);
    setIsConnected(false);
    localStorage.removeItem("walletConnected");
    
    toast({
      title: "Wallet Disconnected",
      description: "Your wallet has been disconnected.",
    });
  };

  // Switch network
  const switchNetwork = async (networkId: string): Promise<boolean> => {
    if (!isMetaMaskAvailable || !isConnected) return false;

    try {
      await window.ethereum.request({
        method: "wallet_switchEthereumChain",
        params: [{ chainId: `0x${parseInt(networkId).toString(16)}` }],
      });
      return true;
    } catch (switchError: any) {
      // This error code indicates that the chain has not been added to MetaMask
      if (switchError.code === 4902) {
        const network = getNetworkById(networkId);
        if (!network) return false;
        
        try {
          await window.ethereum.request({
            method: "wallet_addEthereumChain",
            params: [
              {
                chainId: `0x${parseInt(networkId).toString(16)}`,
                chainName: network.name,
                rpcUrls: [network.rpcUrl],
                blockExplorerUrls: [network.blockExplorer],
                nativeCurrency: {
                  name: network.currency,
                  symbol: network.currency,
                  decimals: 18,
                },
              },
            ],
          });
          return true;
        } catch (addError) {
          console.error("Error adding network:", addError);
          return false;
        }
      }
      console.error("Error switching network:", switchError);
      return false;
    }
  };

  // Helper to get network by ID
  const getNetworkById = (id: string): Network | undefined => {
    return NETWORKS.find(network => network.id === id);
  };

  // Get current network
  const getCurrentNetwork = (): Network | undefined => {
    if (!chainId) return getNetworkById(DEFAULT_NETWORK);
    return getNetworkById(chainId) || getNetworkById(DEFAULT_NETWORK);
  };

  // Transaction modal controls
  const setTransactionStatus = (
    status: TransactionStatus,
    title: string,
    message: string,
    txHash?: string
  ) => {
    setTransaction({
      status,
      title,
      message,
      txHash,
      isOpen: true,
    });
  };

  const closeTransactionModal = () => {
    setTransaction(prev => ({ ...prev, isOpen: false }));
  };

  // Event listeners for MetaMask
  useEffect(() => {
    if (!isMetaMaskAvailable) return;

    const handleAccountsChanged = (accounts: string[]) => {
      if (accounts.length === 0) {
        // User disconnected their wallet
        disconnectWallet();
      } else if (accounts[0] !== account) {
        setAccount(accounts[0]);
      }
    };

    const handleChainChanged = (chainIdHex: string) => {
      const newChainId = parseInt(chainIdHex, 16).toString();
      setChainId(newChainId);
      
      toast({
        title: "Network Changed",
        description: `Switched to ${getNetworkById(newChainId)?.name || "Unknown Network"}`,
      });
    };

    // Check if user was previously connected
    const checkConnection = async () => {
      const wasConnected = localStorage.getItem("walletConnected") === "true";
      if (wasConnected) {
        try {
          const provider = getProvider();
          if (!provider) return;
          
          const accounts = await provider.send("eth_accounts", []);
          if (accounts.length > 0) {
            const network = await provider.getNetwork();
            setAccount(accounts[0]);
            setChainId(network.chainId.toString());
            setIsConnected(true);
          } else {
            localStorage.removeItem("walletConnected");
          }
        } catch (error) {
          console.error("Error checking wallet connection:", error);
          localStorage.removeItem("walletConnected");
        }
      }
    };

    checkConnection();

    // Add event listeners
    window.ethereum.on("accountsChanged", handleAccountsChanged);
    window.ethereum.on("chainChanged", handleChainChanged);

    // Clean up event listeners
    return () => {
      window.ethereum.removeListener("accountsChanged", handleAccountsChanged);
      window.ethereum.removeListener("chainChanged", handleChainChanged);
    };
  }, [account]);

  const value: Web3ContextType = {
    account,
    chainId,
    isConnected,
    isConnecting,
    connectWallet,
    disconnectWallet,
    switchNetwork,
    getNetworkById,
    getCurrentNetwork,
    transaction,
    setTransactionStatus,
    closeTransactionModal,
  };

  return <Web3Context.Provider value={value}>{children}</Web3Context.Provider>;
}

// Custom hook to use Web3 context
export function useWeb3() {
  const context = useContext(Web3Context);
  if (context === undefined) {
    throw new Error("useWeb3 must be used within a Web3Provider");
  }
  return context;
}
