import { Switch, Route } from "wouter";
import { Web3Provider } from "./contexts/Web3Context";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import TransactionModal from "@/components/TransactionModal";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <Web3Provider>
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="flex-grow">
          <Router />
        </div>
        <Footer />
        <TransactionModal />
      </div>
    </Web3Provider>
  );
}

export default App;
