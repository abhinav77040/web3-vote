// Network configurations
export const NETWORKS = [
  {
    id: "11155111",
    name: "Sepolia Testnet",
    isTestnet: true,
    rpcUrl: "https://sepolia.infura.io/v3/",
    blockExplorer: "https://sepolia.etherscan.io",
    currency: "ETH",
    badge: "bg-blue-100 text-blue-800"
  },
  {
    id: "80001",
    name: "Mumbai Testnet",
    isTestnet: true,
    rpcUrl: "https://polygon-mumbai.infura.io/v3/",
    blockExplorer: "https://mumbai.polygonscan.com",
    currency: "MATIC",
    badge: "bg-purple-100 text-purple-800"
  },
  {
    id: "5",
    name: "Goerli Testnet",
    isTestnet: true,
    rpcUrl: "https://goerli.infura.io/v3/",
    blockExplorer: "https://goerli.etherscan.io",
    currency: "ETH",
    badge: "bg-green-100 text-green-800"
  },
  {
    id: "84531",
    name: "Base Goerli Testnet",
    isTestnet: true,
    rpcUrl: "https://base-goerli.infura.io/v3/",
    blockExplorer: "https://goerli.basescan.org",
    currency: "ETH",
    badge: "bg-green-100 text-green-800"
  },
  {
    id: "421614",
    name: "Arbitrum Sepolia",
    isTestnet: true,
    rpcUrl: "https://arbitrum-sepolia.infura.io/v3/",
    blockExplorer: "https://sepolia-explorer.arbitrum.io",
    currency: "ETH",
    badge: "bg-orange-100 text-orange-800"
  },
  {
    id: "11155420", 
    name: "Optimism Sepolia",
    isTestnet: true,
    rpcUrl: "https://optimism-sepolia.infura.io/v3/",
    blockExplorer: "https://sepolia-explorer.optimism.io",
    currency: "ETH",
    badge: "bg-red-100 text-red-800"
  },
  {
    id: "1",
    name: "Ethereum Mainnet",
    isTestnet: false,
    rpcUrl: "https://mainnet.infura.io/v3/",
    blockExplorer: "https://etherscan.io",
    currency: "ETH",
    badge: "bg-blue-100 text-blue-800"
  },
  {
    id: "137",
    name: "Polygon Mainnet",
    isTestnet: false,
    rpcUrl: "https://polygon-mainnet.infura.io/v3/",
    blockExplorer: "https://polygonscan.com",
    currency: "MATIC",
    badge: "bg-purple-100 text-purple-800"
  },
  {
    id: "42161",
    name: "Arbitrum One",
    isTestnet: false,
    rpcUrl: "https://arbitrum-mainnet.infura.io/v3/",
    blockExplorer: "https://arbiscan.io",
    currency: "ETH",
    badge: "bg-orange-100 text-orange-800"
  },
  {
    id: "10",
    name: "Optimism Mainnet",
    isTestnet: false,
    rpcUrl: "https://optimism-mainnet.infura.io/v3/",
    blockExplorer: "https://optimistic.etherscan.io",
    currency: "ETH",
    badge: "bg-red-100 text-red-800"
  },
  {
    id: "8453",
    name: "Base Mainnet",
    isTestnet: false,
    rpcUrl: "https://base-mainnet.infura.io/v3/",
    blockExplorer: "https://basescan.org",
    currency: "ETH",
    badge: "bg-green-100 text-green-800"
  }
];

// Default network
export const DEFAULT_NETWORK = "11155111";

// Contract addresses (these would be deployed contract addresses)
export const CONTRACT_ADDRESSES: Record<string, string> = {
  "11155111": "0xd9145CCE52D386f254917e481eB44e9943F39138", // Sepolia (example contract address)
  "80001": "0xd8b934580fcE35a11B58C6D73aDeE468a2833fa8",    // Mumbai (example contract address)
  "5": "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266",        // Goerli (example contract address)
  "84531": "0x8626f6940E2eb28930eFb4CeF49B2d1F2C9C1199",    // Base Goerli (example contract address)
  // Add other networks as needed
};

// Voting duration options in hours
export const VOTING_DURATIONS = [
  { value: 1, label: "1 hour" },
  { value: 6, label: "6 hours" },
  { value: 12, label: "12 hours" },
  { value: 24, label: "24 hours" },
  { value: 48, label: "2 days" },
  { value: 72, label: "3 days" },
];

// Proposal list filter options
export const FILTER_OPTIONS = [
  { value: "all", label: "All Proposals" },
  { value: "ending_soon", label: "Ending Soon" },
  { value: "most_votes", label: "Most Votes" },
  { value: "recent", label: "Recently Added" },
];
