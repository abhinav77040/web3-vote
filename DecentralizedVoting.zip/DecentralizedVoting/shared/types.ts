// Basic blockchain types
export interface Network {
  id: string;
  name: string;
  isTestnet: boolean;
  rpcUrl: string;
  blockExplorer: string;
  currency: string;
  badge: string;
}

export interface ProposalData {
  id: number;
  title: string;
  description: string;
  creatorAddress: string;
  network: string;
  chainId: number;
  contractAddress: string;
  proposalId: string;
  duration: number;
  endTime: Date;
  active: boolean;
  createdAt: Date;
  yesVotes?: number;
  noVotes?: number;
}

export interface VoteData {
  id: number;
  proposalId: number;
  voterAddress: string;
  vote: boolean;
  txHash: string;
  createdAt: Date;
}

// Transaction states
export type TransactionStatus = "idle" | "processing" | "success" | "error";

export interface TransactionState {
  status: TransactionStatus;
  title: string;
  message: string;
  txHash?: string;
  isOpen: boolean;
}

// Web3 context types
export interface Web3ContextType {
  account: string | null;
  chainId: string | null;
  isConnected: boolean;
  isConnecting: boolean;
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
  switchNetwork: (chainId: string) => Promise<boolean>;
  getNetworkById: (id: string) => Network | undefined;
  getCurrentNetwork: () => Network | undefined;
  transaction: TransactionState;
  setTransactionStatus: (status: TransactionStatus, title: string, message: string, txHash?: string) => void;
  closeTransactionModal: () => void;
}

// Form types
export interface CreateProposalFormData {
  title: string;
  description: string;
  duration: number;
}
