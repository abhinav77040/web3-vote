import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertProposalSchema, insertVoteSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // All routes are prefixed with /api
  
  // Get all proposals for a network
  app.get("/api/proposals/:chainId", async (req, res) => {
    try {
      const { chainId } = req.params;
      const proposals = await storage.getProposalsByChainId(parseInt(chainId));
      
      // Add vote counts to each proposal
      const proposalsWithVotes = await Promise.all(proposals.map(async (proposal) => {
        const votes = await storage.getVotesByProposalId(proposal.id);
        
        // Count yes and no votes
        let yesVotes = 0;
        let noVotes = 0;
        
        votes.forEach(vote => {
          if (vote.vote) {
            yesVotes++;
          } else {
            noVotes++;
          }
        });
        
        return {
          ...proposal,
          yesVotes,
          noVotes
        };
      }));
      
      res.json(proposalsWithVotes);
    } catch (error) {
      console.error("Error fetching proposals:", error);
      res.status(500).json({ message: "Failed to fetch proposals" });
    }
  });

  // Get completed proposals
  app.get("/api/proposals/:chainId/completed", async (req, res) => {
    try {
      const { chainId } = req.params;
      const proposals = await storage.getCompletedProposals(parseInt(chainId));
      res.json(proposals);
    } catch (error) {
      console.error("Error fetching completed proposals:", error);
      res.status(500).json({ message: "Failed to fetch completed proposals" });
    }
  });

  // Get a single proposal by ID
  app.get("/api/proposals/:chainId/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const proposal = await storage.getProposal(parseInt(id));
      
      if (!proposal) {
        return res.status(404).json({ message: "Proposal not found" });
      }
      
      // Get votes for this proposal
      const votes = await storage.getVotesByProposalId(proposal.id);
      
      // Count votes
      let yesVotes = 0;
      let noVotes = 0;
      
      votes.forEach(vote => {
        if (vote.vote) {
          yesVotes++;
        } else {
          noVotes++;
        }
      });
      
      res.json({
        ...proposal,
        yesVotes,
        noVotes,
        votes
      });
    } catch (error) {
      console.error("Error fetching proposal:", error);
      res.status(500).json({ message: "Failed to fetch proposal" });
    }
  });

  // Create a new proposal
  app.post("/api/proposals", async (req, res) => {
    try {
      // Make sure endTime is properly converted to a Date
      const body = { ...req.body };
      
      // If endTime is a string, convert it to a Date
      if (body.endTime && typeof body.endTime === 'string') {
        try {
          body.endTime = new Date(body.endTime);
          console.log("Converted endTime to date:", body.endTime);
        } catch (e) {
          return res.status(400).json({ 
            message: "Invalid date format for endTime", 
            details: "The endTime must be a valid ISO string or Date object" 
          });
        }
      }
      
      // Parse and validate the data
      const proposalData = insertProposalSchema.parse(body);
      const newProposal = await storage.createProposal(proposalData);
      res.status(201).json(newProposal);
    } catch (error) {
      if (error instanceof z.ZodError) {
        console.error("Validation error:", error.errors);
        return res.status(400).json({ message: "Invalid proposal data", errors: error.errors });
      }
      console.error("Error creating proposal:", error);
      res.status(500).json({ message: "Failed to create proposal" });
    }
  });

  // Record a vote
  app.post("/api/votes", async (req, res) => {
    try {
      const voteData = insertVoteSchema.parse(req.body);
      const newVote = await storage.recordVote(voteData);
      res.status(201).json(newVote);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid vote data", errors: error.errors });
      }
      console.error("Error recording vote:", error);
      res.status(500).json({ message: "Failed to record vote" });
    }
  });

  // Mark proposal as inactive
  app.patch("/api/proposals/:id/complete", async (req, res) => {
    try {
      const { id } = req.params;
      const proposal = await storage.getProposal(parseInt(id));
      
      if (!proposal) {
        return res.status(404).json({ message: "Proposal not found" });
      }
      
      const updatedProposal = await storage.markProposalAsInactive(parseInt(id));
      res.json(updatedProposal);
    } catch (error) {
      console.error("Error completing proposal:", error);
      res.status(500).json({ message: "Failed to complete proposal" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
