import { users, proposals, votes, type User, type InsertUser, type Proposal, type InsertProposal, type Vote, type InsertVote } from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Proposal operations
  getProposal(id: number): Promise<Proposal | undefined>;
  getProposalsByChainId(chainId: number): Promise<Proposal[]>;
  getCompletedProposals(chainId: number): Promise<Proposal[]>;
  createProposal(proposal: InsertProposal): Promise<Proposal>;
  markProposalAsInactive(id: number): Promise<Proposal>;
  
  // Vote operations
  getVote(id: number): Promise<Vote | undefined>;
  getVotesByProposalId(proposalId: number): Promise<Vote[]>;
  getVoteByVoterAndProposal(voterAddress: string, proposalId: number): Promise<Vote | undefined>;
  recordVote(vote: InsertVote): Promise<Vote>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private proposals: Map<number, Proposal>;
  private votes: Map<number, Vote>;
  private userIdCounter: number;
  private proposalIdCounter: number;
  private voteIdCounter: number;

  constructor() {
    this.users = new Map();
    this.proposals = new Map();
    this.votes = new Map();
    this.userIdCounter = 1;
    this.proposalIdCounter = 1;
    this.voteIdCounter = 1;

    // Add some sample data for testing
    this.addSampleData();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Proposal operations
  async getProposal(id: number): Promise<Proposal | undefined> {
    return this.proposals.get(id);
  }
  
  async getProposalsByChainId(chainId: number): Promise<Proposal[]> {
    return Array.from(this.proposals.values())
      .filter(proposal => proposal.chainId === chainId && proposal.active);
  }
  
  async getCompletedProposals(chainId: number): Promise<Proposal[]> {
    const now = new Date();
    return Array.from(this.proposals.values())
      .filter(proposal => proposal.chainId === chainId && (!proposal.active || new Date(proposal.endTime) < now))
      .sort((a, b) => new Date(b.endTime).getTime() - new Date(a.endTime).getTime());
  }
  
  async createProposal(insertProposal: InsertProposal): Promise<Proposal> {
    const id = this.proposalIdCounter++;
    const proposal: Proposal = { ...insertProposal, id };
    this.proposals.set(id, proposal);
    return proposal;
  }
  
  async markProposalAsInactive(id: number): Promise<Proposal> {
    const proposal = this.proposals.get(id);
    if (!proposal) {
      throw new Error(`Proposal with id ${id} not found`);
    }
    
    const updatedProposal: Proposal = { ...proposal, active: false };
    this.proposals.set(id, updatedProposal);
    return updatedProposal;
  }
  
  // Vote operations
  async getVote(id: number): Promise<Vote | undefined> {
    return this.votes.get(id);
  }
  
  async getVotesByProposalId(proposalId: number): Promise<Vote[]> {
    return Array.from(this.votes.values())
      .filter(vote => vote.proposalId === proposalId);
  }
  
  async getVoteByVoterAndProposal(voterAddress: string, proposalId: number): Promise<Vote | undefined> {
    return Array.from(this.votes.values())
      .find(vote => vote.voterAddress.toLowerCase() === voterAddress.toLowerCase() && vote.proposalId === proposalId);
  }
  
  async recordVote(insertVote: InsertVote): Promise<Vote> {
    // Check if voter has already voted on this proposal
    const existingVote = await this.getVoteByVoterAndProposal(insertVote.voterAddress, insertVote.proposalId);
    if (existingVote) {
      throw new Error("Voter has already voted on this proposal");
    }
    
    // Check if proposal exists
    const proposal = await this.getProposal(insertVote.proposalId);
    if (!proposal) {
      throw new Error(`Proposal with id ${insertVote.proposalId} not found`);
    }
    
    // Check if proposal is still active
    if (!proposal.active) {
      throw new Error("Cannot vote on inactive proposal");
    }
    
    // Check if proposal has ended
    if (new Date(proposal.endTime) < new Date()) {
      throw new Error("Voting period has ended");
    }
    
    // Record the vote
    const id = this.voteIdCounter++;
    const vote: Vote = { ...insertVote, id, createdAt: new Date() };
    this.votes.set(id, vote);
    return vote;
  }
  
  // Helper to add sample data for testing
  private addSampleData() {
    // Sample proposals for Sepolia
    const sepoliaProposal1: Proposal = {
      id: this.proposalIdCounter++,
      title: "Community Treasury Allocation",
      description: "Proposal to allocate 500 ETH from the community treasury for development grants.",
      creatorAddress: "0x83ab21c567de4bcfe6d1623c3b2c5e934d23b21c",
      network: "11155111",
      chainId: 11155111,
      contractAddress: "0x0000000000000000000000000000000000000000",
      proposalId: "1",
      duration: 5,
      endTime: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000), // 2 days from now
      active: true,
      createdAt: new Date(),
    };
    this.proposals.set(sepoliaProposal1.id, sepoliaProposal1);
    
    // Add votes for this proposal
    for (let i = 0; i < 256; i++) {
      const vote: Vote = {
        id: this.voteIdCounter++,
        proposalId: sepoliaProposal1.id,
        voterAddress: `0x${Math.random().toString(16).substring(2, 10)}`,
        vote: true, // Yes vote
        txHash: `0x${Math.random().toString(16).substring(2, 66)}`,
        createdAt: new Date(),
      };
      this.votes.set(vote.id, vote);
    }
    
    for (let i = 0; i < 124; i++) {
      const vote: Vote = {
        id: this.voteIdCounter++,
        proposalId: sepoliaProposal1.id,
        voterAddress: `0x${Math.random().toString(16).substring(2, 10)}`,
        vote: false, // No vote
        txHash: `0x${Math.random().toString(16).substring(2, 66)}`,
        createdAt: new Date(),
      };
      this.votes.set(vote.id, vote);
    }
    
    // Sample proposal for Mumbai
    const mumbaiProposal: Proposal = {
      id: this.proposalIdCounter++,
      title: "Protocol Update v2.5",
      description: "Vote on implementing the latest protocol update which includes security fixes and gas optimizations.",
      creatorAddress: "0x71C8Fe2e5A0c71F85b92B3CC06be4598b80C8Fe2",
      network: "80001",
      chainId: 80001,
      contractAddress: "0x0000000000000000000000000000000000000000",
      proposalId: "2",
      duration: 7,
      endTime: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 days from now
      active: true,
      createdAt: new Date(),
    };
    this.proposals.set(mumbaiProposal.id, mumbaiProposal);
    
    // Add votes for this proposal
    for (let i = 0; i < 437; i++) {
      const vote: Vote = {
        id: this.voteIdCounter++,
        proposalId: mumbaiProposal.id,
        voterAddress: `0x${Math.random().toString(16).substring(2, 10)}`,
        vote: true, // Yes vote
        txHash: `0x${Math.random().toString(16).substring(2, 66)}`,
        createdAt: new Date(),
      };
      this.votes.set(vote.id, vote);
    }
    
    for (let i = 0; i < 12; i++) {
      const vote: Vote = {
        id: this.voteIdCounter++,
        proposalId: mumbaiProposal.id,
        voterAddress: `0x${Math.random().toString(16).substring(2, 10)}`,
        vote: false, // No vote
        txHash: `0x${Math.random().toString(16).substring(2, 66)}`,
        createdAt: new Date(),
      };
      this.votes.set(vote.id, vote);
    }
    
    // Sample proposal for Base Goerli
    const baseGoerliProposal: Proposal = {
      id: this.proposalIdCounter++,
      title: "Governance Parameter Change",
      description: "Proposal to adjust the voting period from 7 days to 5 days for standard proposals.",
      creatorAddress: "0xbc7e44a567de4bcfe6d1623c3b2c5e934de44a",
      network: "84531",
      chainId: 84531,
      contractAddress: "0x0000000000000000000000000000000000000000",
      proposalId: "3",
      duration: 3,
      endTime: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000), // 1 day from now
      active: true,
      createdAt: new Date(),
    };
    this.proposals.set(baseGoerliProposal.id, baseGoerliProposal);
    
    // Add votes for this proposal
    for (let i = 0; i < 89; i++) {
      const vote: Vote = {
        id: this.voteIdCounter++,
        proposalId: baseGoerliProposal.id,
        voterAddress: `0x${Math.random().toString(16).substring(2, 10)}`,
        vote: true, // Yes vote
        txHash: `0x${Math.random().toString(16).substring(2, 66)}`,
        createdAt: new Date(),
      };
      this.votes.set(vote.id, vote);
    }
    
    for (let i = 0; i < 134; i++) {
      const vote: Vote = {
        id: this.voteIdCounter++,
        proposalId: baseGoerliProposal.id,
        voterAddress: `0x${Math.random().toString(16).substring(2, 10)}`,
        vote: false, // No vote
        txHash: `0x${Math.random().toString(16).substring(2, 66)}`,
        createdAt: new Date(),
      };
      this.votes.set(vote.id, vote);
    }
    
    // Sample completed proposals for results page
    const completedProposal1: Proposal = {
      id: this.proposalIdCounter++,
      title: "Treasury Allocation Q3",
      description: "Proposal to allocate treasury funds for Q3 initiatives",
      creatorAddress: "0x83ab21c567de4bcfe6d1623c3b2c5e934d23b21c",
      network: "11155111",
      chainId: 11155111,
      contractAddress: "0x0000000000000000000000000000000000000000",
      proposalId: "4",
      duration: 7,
      endTime: new Date("2023-06-12"),
      active: false,
      createdAt: new Date("2023-06-05"),
    };
    this.proposals.set(completedProposal1.id, completedProposal1);
    
    // Votes for completed proposal 1
    for (let i = 0; i < 423; i++) {
      const vote: Vote = {
        id: this.voteIdCounter++,
        proposalId: completedProposal1.id,
        voterAddress: `0x${Math.random().toString(16).substring(2, 10)}`,
        vote: true,
        txHash: `0x${Math.random().toString(16).substring(2, 66)}`,
        createdAt: new Date("2023-06-08"),
      };
      this.votes.set(vote.id, vote);
    }
    
    for (let i = 0; i < 119; i++) {
      const vote: Vote = {
        id: this.voteIdCounter++,
        proposalId: completedProposal1.id,
        voterAddress: `0x${Math.random().toString(16).substring(2, 10)}`,
        vote: false,
        txHash: `0x${Math.random().toString(16).substring(2, 66)}`,
        createdAt: new Date("2023-06-09"),
      };
      this.votes.set(vote.id, vote);
    }
    
    const completedProposal2: Proposal = {
      id: this.proposalIdCounter++,
      title: "Governance Update",
      description: "Proposal to update governance parameters",
      creatorAddress: "0x71C8Fe2e5A0c71F85b92B3CC06be4598b80C8Fe2",
      network: "80001",
      chainId: 80001,
      contractAddress: "0x0000000000000000000000000000000000000000",
      proposalId: "5",
      duration: 7,
      endTime: new Date("2023-05-28"),
      active: false,
      createdAt: new Date("2023-05-21"),
    };
    this.proposals.set(completedProposal2.id, completedProposal2);
    
    // Votes for completed proposal 2
    for (let i = 0; i < 136; i++) {
      const vote: Vote = {
        id: this.voteIdCounter++,
        proposalId: completedProposal2.id,
        voterAddress: `0x${Math.random().toString(16).substring(2, 10)}`,
        vote: true,
        txHash: `0x${Math.random().toString(16).substring(2, 66)}`,
        createdAt: new Date("2023-05-25"),
      };
      this.votes.set(vote.id, vote);
    }
    
    for (let i = 0; i < 187; i++) {
      const vote: Vote = {
        id: this.voteIdCounter++,
        proposalId: completedProposal2.id,
        voterAddress: `0x${Math.random().toString(16).substring(2, 10)}`,
        vote: false,
        txHash: `0x${Math.random().toString(16).substring(2, 66)}`,
        createdAt: new Date("2023-05-26"),
      };
      this.votes.set(vote.id, vote);
    }
    
    const completedProposal3: Proposal = {
      id: this.proposalIdCounter++,
      title: "Fee Structure Change",
      description: "Proposal to update fee structure",
      creatorAddress: "0xbc7e44a567de4bcfe6d1623c3b2c5e934de44a",
      network: "84531",
      chainId: 84531,
      contractAddress: "0x0000000000000000000000000000000000000000",
      proposalId: "6",
      duration: 5,
      endTime: new Date("2023-04-15"),
      active: false,
      createdAt: new Date("2023-04-10"),
    };
    this.proposals.set(completedProposal3.id, completedProposal3);
    
    // Votes for completed proposal 3
    for (let i = 0; i < 562; i++) {
      const vote: Vote = {
        id: this.voteIdCounter++,
        proposalId: completedProposal3.id,
        voterAddress: `0x${Math.random().toString(16).substring(2, 10)}`,
        vote: true,
        txHash: `0x${Math.random().toString(16).substring(2, 66)}`,
        createdAt: new Date("2023-04-12"),
      };
      this.votes.set(vote.id, vote);
    }
    
    for (let i = 0; i < 55; i++) {
      const vote: Vote = {
        id: this.voteIdCounter++,
        proposalId: completedProposal3.id,
        voterAddress: `0x${Math.random().toString(16).substring(2, 10)}`,
        vote: false,
        txHash: `0x${Math.random().toString(16).substring(2, 66)}`,
        createdAt: new Date("2023-04-13"),
      };
      this.votes.set(vote.id, vote);
    }
  }
}

export const storage = new MemStorage();
